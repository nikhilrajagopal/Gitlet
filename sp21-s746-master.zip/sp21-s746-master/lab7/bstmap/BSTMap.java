package bstmap;

import java.util.Iterator;
import java.util.Set;

public class BSTMap<K extends Comparable<K>, V> implements Map61B<K, V> {
    private BSTNode root;
    private int size;

    @Override
    public Iterator<K> iterator() {
        throw new UnsupportedOperationException();
    }

    private class BSTNode{
        private K key;
        private V value;
        private BSTNode left;
        private BSTNode right;

        public BSTNode(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    public BSTMap() {
        this.clear();
    }

    @Override
    public void clear() {
        this.root = null;
        this.size = 0;
    }

    @Override
    public int size() {
        return this.size;
    }

    public boolean containsKey(K key) {
        return getHelper(key, root) != null;
    }

    @Override
    public V get(K key) {
        BSTNode node = getHelper(key, root);
        if (node == null) {
            return null;
        } else {
            return node.value;
        }
    }

    private BSTNode getHelper(K key, BSTNode p) {
        if (p == null) {
            return null;
        }
        int compare = key.compareTo(p.key);
        if (compare < 0) {
            return getHelper(key, p.left);
        } else if (compare > 0) {
            return getHelper(key, p.right);
        } else {
            return p;
        }
    }

    @Override
    public void put(K key, V value) {
        root = putHelper(key, value, root);
        this.size++;
    }

    private BSTNode putHelper(K key, V value, BSTNode p) {
        if (p == null) {
            return new BSTNode(key, value);
        }
        int compare = key.compareTo(p.key);
        if (compare < 0) {
            p.left = putHelper(key, value, p.left);
        } else if (compare > 0) {
            p.right = putHelper(key, value, p.right);
        } else {
            p.value = value;
        }
        return p;
    }

    public void printInOrder() {
        printHelper(root);
        System.out.println();
    }

    private void printHelper(BSTNode p) {
        if (p == null) {
            return;
        }
        printHelper(p.left);
        System.out.println("(" + p.key.toString() + ", " + p.value.toString() + ") ");
        printHelper(p.right);
    }

    @Override
    public Set<K> keySet() {
        throw new UnsupportedOperationException();
    }

    @Override
    public V remove(K key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public V remove(K key, V value) {
        throw new UnsupportedOperationException();
    }

}
