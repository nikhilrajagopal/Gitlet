package deque;
import java.util.Comparator;

public class ComparatorT<T> implements Comparator {
    public int compare(Object one, Object two) {
        Integer s1 = (Integer) one;
        Integer s2 = (Integer) two;
        if (s1 > s2) {
            return 1;
        } else {
            return -1;
        }
    }
}
