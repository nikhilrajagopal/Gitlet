package deque;
import java.util.Comparator;

public class MaxArrayDeque<T> extends ArrayDeque<T> {
    private Comparator<T> comparison;

    public MaxArrayDeque(Comparator<T> c) {
        super();
        comparison = c;
    }
    public T max() {
        if (this.size() == 0) {
            return null;
        }
        T index = (T) this.get(0);
        for (int i = 1; i < this.size(); i++) {
            if (comparison.compare(this.get(i), index) > 0) {
                index = this.get(i);
            }
        }
        return index;
    }

    public T max(Comparator<T> c) {
        if (this.size() == 0) {
            return null;
        }
        T index = (T) this.get(0);
        for (int i = 1; i < this.size(); i++) {
            if (c.compare(this.get(i), index) > 0) {
                index = this.get(i);
            }
        }
        return index;
    }
}
