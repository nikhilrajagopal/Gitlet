package deque;
import java.util.Iterator;

public class ArrayDeque<T> implements Iterable<T>, Deque<T> {
    private T[] items;
    private int nextFirst;
    private int nextLast;
    private int size;

    public ArrayDeque() {
        items = (T[]) new Object[8];
        nextFirst = 0;
        nextLast = 1;
        size = 0;
    }

    private void resize(int capacity) {
        T[] a = (T[]) new Object[capacity];
        int x;
        if (nextFirst + 1 > items.length - 1) {
            x = 0;
        } else {
            x = nextFirst + 1;
        }
        for (int i = 0; i < size; i++) {
            a[i] = items[x];
            if (x + 1 > items.length - 1) {
                x = 0;
            } else {
                x = x + 1;
            }
        }
        items = a;
        nextLast = size;
        nextFirst = capacity - 1;
    }

    public void addLast(T x) {
        if (size == items.length) {
            resize(items.length * 2);
        }
        items[nextLast] = x;
        if ((nextLast + 1) > (items.length - 1)) {
            nextLast = 0;
        } else {
            nextLast += 1;
        }
        size = size + 1;
    }

    public void addFirst(T x) {
        if (size == items.length) {
            resize(items.length * 2);
        }
        items[nextFirst] = x;
        if ((nextFirst - 1) < 0) {
            nextFirst = items.length - 1;
        } else {
            nextFirst -= 1;
        }
        size = size + 1;
    }

    public T removeFirst() {
        if (size == 0) {
            return null;
        }
        int indexOfRemoved;
        if ((nextFirst + 1) > (items.length - 1)) {
            indexOfRemoved = 0;
            nextFirst = 0;
        } else {
            indexOfRemoved = nextFirst + 1;
            nextFirst += 1;
        }
        T itemOfRemoved = items[indexOfRemoved];
        items[indexOfRemoved] = null;
        size -= 1;
        if ((items.length >= 16) && ((size / 0.25) <= (items.length * 1.0))) {
            resize(items.length / 2);
        }
        return itemOfRemoved;
    }

    public T removeLast() {
        if (size == 0) {
            return null;
        }
        int indexOfRemoved;
        if ((nextLast - 1) < 0) {
            indexOfRemoved = items.length - 1;
            nextLast = items.length - 1;
        } else {
            indexOfRemoved = nextLast - 1;
            nextLast -= 1;
        }
        T itemOfRemoved = items[indexOfRemoved];
        items[indexOfRemoved] = null;
        size -= 1;
        if ((items.length >= 16) && ((size / 0.25) <= (items.length * 1.0))) {
            resize(items.length / 2);
        }
        return itemOfRemoved;
    }

    public int size() {
        return size;
    }

    public T get(int index) {
        if (index >= size) {
            return null;
        }
        int itemLocation;
        if ((nextFirst + 1) > (items.length - 1)) {
            itemLocation = 0;
        } else {
            itemLocation = nextFirst + 1;
        }
        int i = 0;
        while (i < index) {
            if ((itemLocation + 1) > (items.length - 1)) {
                itemLocation = 0;
            } else {
                itemLocation += 1;
            }
            i++;
        }
        return items[itemLocation];
    }

    public Iterator<T> iterator() {
        return new ArrayDequeIterator();
    }

    private class ArrayDequeIterator implements Iterator<T> {
        private int wizPos;
        private int counter;
        ArrayDequeIterator() {
            wizPos = 0;
            if ((nextFirst + 1) > (items.length - 1)) {
                counter = 0;
            } else {
                counter = nextFirst + 1;
            }
        }

        public boolean hasNext() {
            return wizPos < size;
        }

        public T next() {
            T returnItem = items[counter];
            if ((counter + 1) > (items.length - 1)) {
                counter = 0;
            } else {
                counter++;
            }
            wizPos++;
            return returnItem;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (!(o instanceof Deque)) {
            return false;
        }
        if (this.size() != ((Deque) o).size()) {
            return false;
        }
        if (this.size() == ((Deque) o).size()) {
            for (int i = 0; i < this.size(); i++) {
                if (!(this.get(i).equals(((Deque) o).get(i)))) {
                    return false;
                }
            }
        }
        return true;
    }

    public void printDeque() {
        int printer = 0;
        if ((nextFirst + 1) > (items.length - 1)) {
            printer = 0;
        } else {
            printer = nextFirst + 1;
        }
        while (printer != nextLast) {
            System.out.print(items[printer] + " ");
            if ((printer + 1) > (items.length - 1)) {
                printer = 0;
            } else {
                printer++;
            }
        }
    }

    /*public static void main(String[] args) {
        ArrayDeque<Integer> test = new ArrayDeque();
        test.addLast(5);
        test.addLast(10);
        test.addLast(15);
        LinkedListDeque<Integer> test1 = new LinkedListDeque<>();
        test1.addLast(5);
        test1.addLast(10);
        test1.addLast(15);
        System.out.println(test.equals(test1));
    }*/
}
