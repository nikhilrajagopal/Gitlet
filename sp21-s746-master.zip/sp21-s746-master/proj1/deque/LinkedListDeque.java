package deque;
import java.util.Iterator;

public class LinkedListDeque<T> implements Iterable<T>, Deque<T> {
    private class EveryNode {
        private T item;
        private EveryNode next;
        private EveryNode prev;

        EveryNode(EveryNode p, T i, EveryNode n) {
            prev = p;
            item = i;
            next = n;
        }
    }
    private EveryNode sentinel;
    private int size;

    public LinkedListDeque() {
        size = 0;
        sentinel = new EveryNode(null, null, null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
    }

    /*public LinkedListDeque(T x) {
        size = 1;
        sentinel = new EveryNode(null, x, null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
    }*/

    public void addFirst(T item) {
        EveryNode node = new EveryNode(sentinel, item, sentinel.next);
        sentinel.next.prev = node;
        sentinel.next = node;
        size++;
    }

    public void addLast(T item) {
        size++;
        EveryNode node = new EveryNode(sentinel.prev, item, sentinel);
        sentinel.prev.next = node;
        sentinel.prev = node;
    }

    public int size() {
        return size;
    }

    public void printDeque() {
        EveryNode start = sentinel.next;
        while (start != sentinel) {
            System.out.println(start.item + " ");
            start = start.next;
        }
    }

    public T get(int index) {
        EveryNode start = sentinel.next;
        if (size == 0) {
            return null;
        }
        if (index == 0) {
            return start.item;
        }
        int counter = 0;
        while (start != sentinel) {
            if (counter == index) {
                return start.item;
            }
            counter++;
            start = start.next;
        }
        return null;
    }

    public T getRecursive(int index) {
        if (size == 0) {
            return null;
        }
        int counter = 0;
        EveryNode start = sentinel.next;
        return getRecursiveHelper(index, counter, start);
    }

    private T getRecursiveHelper(int index, int counter, EveryNode start) {
        if (index == 0 || index == counter) {
            return start.item;
        }
        return getRecursiveHelper(index, counter + 1, start.next);
    }

    public T removeFirst() {
        if (size == 0) {
            return null;
        } else {
            T returner = sentinel.next.item;
            size--;
            EveryNode first = sentinel.next.next;
            first.prev = sentinel;
            sentinel.next = first;
            return returner;
        }
    }

    public T removeLast() {
        if (size == 0) {
            return null;
        }  else {
            T returner = sentinel.prev.item;
            size--;
            EveryNode last = sentinel.prev.prev;
            last.next = sentinel;
            sentinel.prev = last;
            return returner;
        }
    }

    public Iterator<T> iterator() {
        return new LinkedListDequeIterator();
    }

    private class LinkedListDequeIterator implements Iterator<T> {
        private EveryNode wizPos;

        LinkedListDequeIterator() {
            wizPos = sentinel.next;
        }

        public boolean hasNext() {
            return wizPos != sentinel;
        }

        public T next() {
            T returnItem = wizPos.item;
            wizPos = wizPos.next;
            return returnItem;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null) {
            return false;
        }
        if (!(o instanceof Deque)) {
            return false;
        }
        if (this.size() != ((Deque) o).size()) {
            return false;
        }
        if (this.size() == ((Deque) o).size()) {
            for (int i = 0; i < this.size(); i++) {
                if (!(this.get(i).equals(((Deque) o).get(i)))) {
                    return false;
                }
            }
        }
        return true;
    }

    /*public static void main(String[] args) {
        LinkedListDeque<Integer> L = new LinkedListDeque<>();
        L.addLast(3);
        L.addLast(9);
        L.addLast(5);
        ArrayDeque<Integer> M = new ArrayDeque<>();
        M.addLast(3);
        M.addLast(9);
        M.addLast(5);
        System.out.println(L.equals(M));
    }*/

}

