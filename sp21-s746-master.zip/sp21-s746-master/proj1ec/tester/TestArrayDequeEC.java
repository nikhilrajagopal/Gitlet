package tester;
import static org.junit.Assert.*;

import edu.princeton.cs.introcs.StdRandom;
import org.junit.Test;
import student.StudentArrayDeque;

//@Test
public class TestArrayDequeEC {
    @Test
    public void tester() {
        StudentArrayDeque<Integer> list1 = new StudentArrayDeque<Integer>();
        ArrayDequeSolution<Integer> list2 = new ArrayDequeSolution<Integer>();
        int length = 3000;
        String[] message = new String[length];
        for (int i = 0; i < length; i++) {
            int operationNumber = StdRandom.uniform(0, 4);
            if (operationNumber == 0 || list1.size() == 0 || list2.size() == 0) {
                int randomValue = StdRandom.uniform(0, 100);
                list1.addLast(randomValue);
                list2.addLast(randomValue);
                message[i] = "addLast(" + randomValue + ")";
            } else if (operationNumber == 1) {
                int randomValue = StdRandom.uniform(0, 100);
                list1.addFirst(randomValue);
                list2.addFirst(randomValue);
                message[i] = "addFirst(" + randomValue + ")";
            } else if (operationNumber == 2) {
                Integer w = list1.removeFirst();
                Integer z = list2.removeFirst();
                message[i] = "removeFirst()";
                assertEquals(thing(message, i), w, z);
            } else {
                Integer x = list1.removeLast();
                Integer y = list2.removeLast();
                message[i] = "removeLast()";
                assertEquals(thing(message, i), x, y);
            }
        }
    }

    public String thing(String[] s, int j) {
        String output = "\n";
        int length = j + 1;
        for (int i = 0; i < length - 1; i++) {
            if (s[i] != null) {
                output += (s[i] + "\n");
            }
        }
        if (s[length - 1] != null) {
            output += (s[length - 1]);
        }
        return output;
    }
}
