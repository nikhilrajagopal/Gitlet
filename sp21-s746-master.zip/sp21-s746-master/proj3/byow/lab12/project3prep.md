# Project 3 Prep

**For tessellating hexagons, one of the hardest parts is figuring out where to place each hexagon/how to easily place hexagons on screen in an algorithmic way.
After looking at your own implementation, consider the implementation provided near the end of the lab.
How did your implementation differ from the given one? What lessons can be learned from it?**

Answer: My implementation was different as I didn't create helper methods for creating a hexagon. This approach would have 
been better as it is more efficient and easier to conceptualize. 

-----

**Can you think of an analogy between the process of tessellating hexagons and randomly generating a world using rooms and hallways?
What is the hexagon and what is the tesselation on the Project 3 side?**

Answer: The hexagon are the rooms, and the tesselation is the hallway. Ultimately, we are creating several different rooms
(i.e. the hexagons) and connecting them with hallways (i.e the tesselation).

-----
**If you were to start working on world generation, what kind of method would you think of writing first? 
Think back to the lab and the process used to eventually get to tessellating hexagons.**

Answer: I would first code a method that initializes all the Tiles, basically setting up the world. 

-----
**What distinguishes a hallway from a room? How are they similar?**

Answer: A room is essentially a node, while a hallway is a pointer (i.e. pathway).
